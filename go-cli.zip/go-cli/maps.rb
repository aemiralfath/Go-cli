class Maps
	def initialize(arr,n)
		@arr = arr
		@n = n
	end
	def maps
		puts "\n"
		puts "============================================"
		puts "                Go-cli Maps"
		puts "============================================"
		puts "\n"
		puts "X axis"
		puts "|"
		@arr.each {|a| print "|#{a}";puts "\n"} #print maps
		@arr[0].length.times { print "---- "   }
		puts "Y axis"
		puts "\n"
		puts "'d' = Driver, 'p'= passanger"
		puts "============================================"
		puts "\n"
	end
end