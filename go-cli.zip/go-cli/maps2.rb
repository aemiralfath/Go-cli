class Maps2
	def initialize(arr,tawal,tujuan)
		@arr = arr
		@Tawal = tawal
		@tujuan = tujuan
	end
	def maps2

		@arr2 = Array.new(@arr[0].length) { Array.new(@arr[0].length) { |i| i = "." }  }
		@arr3 = Array.new

		@arr3 << "start at #{@Tawal}"
		if @Tawal[0]< @tujuan[0]
			@Tawal[0].upto(@tujuan[0]) {|a| @arr2[a][@Tawal[1]] = "#"  }
			@arr3 << "go to [#{@tujuan[0]},#{@Tawal[1]}]"
			if @Tawal[1]>@tujuan[1]
				@arr3 << "turn left"
				(@Tawal[1]-1).downto(@tujuan[1]-1) { |a| @arr2[@tujuan[0]][a] = "#" }
				@arr3 << "go to #{@tujuan}"
			elsif @Tawal[1]<@tujuan[1]
				@arr3 << "turn right"
				(@Tawal[1]+1).upto(@tujuan[1]) { |a| @arr2[@tujuan[0]][a] ="#" }
				@arr3 << "go to #{@tujuan}"
			end
			@arr3 << "finish at #{@tujuan}"

		elsif @Tawal[0] > @tujuan[0]
			@Tawal[0].downto(@tujuan[0]) { |a| @arr2[a][@Tawal[1]] ="#"  }
			@arr3 << "go to [#{@tujuan[0]},#{@Tawal[1]}]"
			if @Tawal[1]>@tujuan[1]
				@arr3 << "turn left"
				(@Tawal[1]-1).downto(@tujuan[1]) { |a| @arr2[@tujuan[0]][a] ="#" }
				@arr3 << "go to #{@tujuan}"
				
			elsif @Tawal[1]<@tujuan[1]
				@arr3 << "turn right"
				(@Tawal[1]+1).upto(@tujuan[1]) { |a| @arr2[@tujuan[0]][a] ="#" }
				@arr3 << "go to #{@tujuan}"
			end
			@arr3 << "finish at #{@tujuan}"
		else
			@arr3 << "go to #{@tujuan}"
			if @Tawal[1]>@tujuan[1]
				(@Tawal[1]).downto(@tujuan[1]) { |a| @arr2[@tujuan[0]][a] ="#" }
			elsif @Tawal[1]<@tujuan[1]
				(@Tawal[1]+1).upto(@tujuan[1]) { |a| @arr2[@tujuan[0]][a] ="#" }
			end
			@arr3 << "finish at #{@tujuan}"
		end

		puts "==============================="
		puts "             Route"
		puts "==============================="
		puts "\n"
		@arr2[@Tawal[0]][@Tawal[1]] = "p"
		@arr2[@tujuan[0]][@tujuan[1]] = "x"
		puts "X axis"
		puts "\n"
		@arr2.each {|a|print "|#{a}";print "\n"}
		@arr[0].length.times { print "---- "   }
		puts "Y axis"
		puts "\n"
		puts "'#' : route, 'x' : destination"
		puts "================================"
		puts "Route description"
		@arr3.each {|a| puts "- #{a}"}
		puts "================================"

	end
end