class User
	
	def user
		@name = "Ahmad Emir Alfatah"
		@saldo = 5000000
		puts "Name   : #{@name}"
		puts "Go-pay : #{@saldo}"
	end
end